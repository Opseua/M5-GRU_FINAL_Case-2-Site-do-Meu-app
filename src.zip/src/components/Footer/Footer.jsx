import "./footer.scss";

export default function Footer() {
  return (
    <>
      <footer className="footer_footer">
        <p className="footer-by_footer">Caderno da Saúde &#169;</p>
      </footer>
    </>
  );
}
