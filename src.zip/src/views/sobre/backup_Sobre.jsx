import React from "react";
import Texto from './Texto';
import './style.css';

function Sobre() {
  return (
    <div className="mainFrame_sobre">

      <div className="texto_sobre">
        <Texto />
      </div>

    </div>
  );
}

export default Sobre;